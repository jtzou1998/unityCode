﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class jamm : MonoBehaviour
{
   
        void OnCollisionEnter(Collision Collection)
        {
            if (Collection.gameObject.name == "Player")
            {
                //AM.OnAchievementWon("Achievement2");
                Debug.Log("Congratulations - You Collected 1 / 10 ArteFacts!");
                Destroy(Collection.gameObject);
            }
        }
    }
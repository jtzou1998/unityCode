﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class coll : MonoBehaviour
{
    
    void OnTriggerEnter2D(Collider2D col)
    {
        if (col.gameObject.layer == LayerMask.NameToLayer("Player"))
        {
            //Destroy (col.gameObject);
            //Destroy (gameObject);
            Debug.Log("load");
            //Destroy(gameObject);
            SceneManager.LoadScene("darksoul");
            //Destroy(col.gameObject);
            // score.changeScore(-10);
        }




    }
}
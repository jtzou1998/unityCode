﻿using UnityEngine;
using System.Collections;

public class BusterGun : MonoBehaviour
{
    Animator mAnimator;
    bool mShooting;
    
    float kShootDuration = 0.25f;
    float mTime;

    public GameObject mBulletPrefab;
    Mario mario;

    AudioSource shoot1;
   // AudioSource shoot2;
   // AudioSource shoot3;

    void Start ()
    {
        mAnimator = transform.parent.GetComponent<Animator>();
        mario = transform.parent.GetComponent<Mario>();


        AudioSource[] audioSources = GetComponents<AudioSource>();
        shoot1 = audioSources[0];
       // shoot2 = audioSources[1];
       // shoot3 = audioSources[2];
    }

    void Update ()
    {
        if(Input.GetButtonDown ("Fire1"))
        {
            // Shoot bullet
            GameObject bulletObject = Instantiate (mBulletPrefab, transform.position, Quaternion.identity) as GameObject;
            Bullet bullet = bulletObject.GetComponent<Bullet>();

            // Set direction of bullet
            bullet.SetDirection(mario.GetFacingDirection());
            
            // Set animation params
            mShooting = true;
            mTime = 0.0f;

            // Play sound
            shoot1.Play ();
        }

        







        if (mShooting)
        {
            mTime += Time.deltaTime;
            if (mTime > kShootDuration)
            {
                mShooting = false;
            }
        }

        UpdateAnimator();
    }

   

    private void UpdateAnimator()
    {
        mAnimator.SetBool("isShooting", mShooting);
    }
}

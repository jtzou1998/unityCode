﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;
public class Jamminger : MonoBehaviour
{
    
    public GameObject mExplosionPrefab;
    Script score = new Script();
    void OnTriggerEnter2D(Collider2D col)
    {
        if(col.gameObject.layer == LayerMask.NameToLayer("BusterBullet"))
        {
            if (gameObject.name == "flyingBullet")
            {
                GameObject flyingBullet = GameObject.Find("flyingBullet");
               
                Instantiate(mExplosionPrefab, transform.position, Quaternion.identity);

                Target target = flyingBullet.transform.GetComponent<Target>();
                target.takeDamage(10);
            }else if(gameObject.name == "trollEnemy")
            {
                GameObject flyingBullet = GameObject.Find("trollEnemy");

                Instantiate(mExplosionPrefab, transform.position, Quaternion.identity);

                Target target = flyingBullet.transform.GetComponent<Target>();
                target.takeDamage(10);
            }
            else if (gameObject.name == "EnemyB")
            {
                GameObject flyingBullet = GameObject.Find("EnemyB");

                Instantiate(mExplosionPrefab, transform.position, Quaternion.identity);

                Target target = flyingBullet.transform.GetComponent<Target>();
                target.takeDamage(10);
            }
            else if (gameObject.name == "EnemyC"|| gameObject.name == "EnemyG")
            {
                GameObject flyingBullet = GameObject.Find("EnemyC");

                Instantiate(mExplosionPrefab, transform.position, Quaternion.identity);

                Target target = flyingBullet.transform.GetComponent<Target>();
                target.takeDamage(10);
            }
            else if (gameObject.name == "EnemyA")
            {
                GameObject flyingBullet = GameObject.Find("EnemyA");

                Instantiate(mExplosionPrefab, transform.position, Quaternion.identity);

                Target target = flyingBullet.transform.GetComponent<Target>();
                target.takeDamage(20);
            }
            else if (gameObject.name == "EnemyE")
            {
                GameObject flyingBullet = GameObject.Find("EnemyE");

                Instantiate(mExplosionPrefab, transform.position, Quaternion.identity);

                
                transform.localScale += new Vector3(2F, 2F, 0);
               
            }



        }

        if (col.gameObject.name == "flyingBullet")
        {
            //Destroy (col.gameObject);
            //Destroy (gameObject);
            Instantiate(mExplosionPrefab, transform.position, Quaternion.identity);
            Destroy(gameObject);
            Destroy(col.gameObject);
        }
        if (col.gameObject.name == "portal")
        {
            Instantiate(mExplosionPrefab, transform.position, Quaternion.identity);
            SceneManager.LoadScene("TheWorld");
            Debug.Log("portal");
        }
        if (col.gameObject.name == "Player")
        {
            //Destroy (col.gameObject);
            //Destroy (gameObject);
            Instantiate(mExplosionPrefab, transform.position, Quaternion.identity);
            Debug.Log("dead");
            //Destroy(gameObject);
            SceneManager.LoadScene("darksoul");
            //Destroy(col.gameObject);
           // score.changeScore(-10);
        }
        if (col.gameObject.layer == LayerMask.NameToLayer("Player"))
        {
            //Destroy (col.gameObject);
            //Destroy (gameObject);
            Camera.main.transform.parent = null;
            Instantiate(mExplosionPrefab, transform.position, Quaternion.identity);

            SceneManager.LoadScene("darksoul");

        }
    }
    
    }



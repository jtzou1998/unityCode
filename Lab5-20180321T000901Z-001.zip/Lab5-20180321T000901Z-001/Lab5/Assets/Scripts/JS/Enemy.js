var isChasing : boolean;
var seeDistance : float = 50;

function Start () {

}

function Awake() {
gameObject.tag = "Enemy";
}


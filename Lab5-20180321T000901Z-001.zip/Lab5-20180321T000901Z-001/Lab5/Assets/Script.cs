﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class Script : MonoBehaviour {
    public Text scoreText;
   
    int score = 100;
    
    public void changeScore(int points)
    {
        score += points;
        scoreText.text = score.ToString();
       
    }
    public int getScore()
    {
        return score;
    }
}

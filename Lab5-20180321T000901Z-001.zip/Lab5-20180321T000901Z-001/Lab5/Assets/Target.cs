﻿
using UnityEngine;

public class Target : MonoBehaviour {
    public int health  = 30;
    public void takeDamage(int amount)
    {
        health = health - amount;
        if (health <= 0)
        {
            Die();
        }
    }
    void Die()
    {
        Destroy(gameObject);
    }
}

Spacecraft simulator includes:
* The model drone
* Demo level

Demo level:
Generated completely at random. The task to bring down as many asteroids. For each shot takes energy (health). Replenish energy can be flown through energy cluster. The number of asteroids and energy clusters can be set.

Controlls:

w/s - speed (default 10 speeds)
a/d - turn the camera
space - fix camera
e - headlight
q - rotate camera to star
LMB - shot